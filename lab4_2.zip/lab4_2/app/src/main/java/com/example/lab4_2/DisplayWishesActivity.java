package com.example.lab4_2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import com.example.lab4_2.model.MyWish;
import com.example.lab4_2.data.DatabaseHandler;
import java.util.ArrayList;

public class DisplayWishesActivity extends Activity {
    private DatabaseHandler dba;
    private ArrayList<MyWish> dbWishes = new ArrayList<>();
    private WishAdapter wishAdapter;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_wishes);

        listView = findViewById(R.id.list);

        refreshData();
    }

    private void refreshData() {
        dbWishes.clear();

        dba = new DatabaseHandler(getApplicationContext());

        ArrayList<MyWish> wishesFromDB = dba.getWishes();

        for (MyWish wish : wishesFromDB) {
            dbWishes.add(wish);
        }

        dba.close();

        wishAdapter = new WishAdapter(this, R.layout.wish_row, dbWishes);
        listView.setAdapter(wishAdapter);
        wishAdapter.notifyDataSetChanged();
    }
}
