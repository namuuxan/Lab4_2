package com.example.lab4_2;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import com.example.lab4_2.model.MyWish;
import com.example.lab4_2.WishDetailActivity;
import com.example.lab4_2.R;

public class WishAdapter extends ArrayAdapter<MyWish> {
    private final Activity activity;
    private final int layoutResource;
    private final ArrayList<MyWish> mData;

    public WishAdapter(Activity act, int resource, ArrayList<MyWish> data) {
        super(act, resource, data);
        this.activity = act;
        this.layoutResource = resource;
        this.mData = data;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public MyWish getItem(int position) {
        return mData.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(activity);
            convertView = inflater.inflate(layoutResource, parent, false);
            holder = new ViewHolder();
            holder.mTitle = convertView.findViewById(R.id.name);
            holder.mDate = convertView.findViewById(R.id.dateText);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        MyWish myWish = getItem(position);
        holder.mTitle.setText(myWish.getTitle());
        holder.mDate.setText(myWish.getRecordDate());

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, WishDetailActivity.class);
                intent.putExtra("content", myWish.getContent());
                intent.putExtra("date", myWish.getRecordDate());
                intent.putExtra("title", myWish.getTitle());
                intent.putExtra("id", myWish.getItemId());
                activity.startActivity(intent);
                Log.v("MyId: ", String.valueOf(myWish.getItemId()));
            }
        });

        return convertView;
    }

    static class ViewHolder {
        TextView mTitle;
        TextView mDate;
    }
}
